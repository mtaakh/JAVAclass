package eltag;

import java.net.URLEncoder;

import javax.servlet.ServletContext;

import model.BbsDAO;

public class MyTagLibrary {
	/*
	 EL에서 호출하기 위한 메소드는 무조건 public static으로 선언해야 한다
	 */
	
	//용도 : 매개변수로 넘겨받은 문자열에 숫자가 아닌 문자가 포함되어있으면 false반환
			//모두 숫자이면 true 반환
	public static boolean isNumber(String value){
		
		char[] chArr = value.toCharArray();
		for(int i=0; i<chArr.length; i++){
			if(!(chArr[i]>='0' && chArr[i]<='9')){
				return false;
			}
		}
		return true;
	}
	
	
	/* 용도 : 주민번호를 매개변수로 받아 두번째 블록의 첫째 숫자가 1이면 남자, 2이면 여자로 반환
	   매개변수는 000000-0000000 형태 */
	public static String getGender(String ssn){
		int beginIndex = ssn.indexOf("-")+1;
		return Integer.parseInt(ssn.substring(beginIndex, beginIndex+1))==1 ? "남자" : "여자";
		
	}
	
	/* /JspServlet/WebContent/10JSTL/ChooseWhenOtherwiseTag.jsp 에서 호출하는 함수
	  용도 : 회원인증 */
	public static boolean isMember(String id, String pass, ServletContext context){
		BbsDAO dao = new BbsDAO(context);
		boolean flag = dao.isMember(id, pass);
		dao.close(); // 자원반납
		return flag;
	}
	
	//파일 다운로드시 파일명 인코딩
	public static String encodeUrl(String url){
		String encodeString = "";
		
		try{
			encodeString = URLEncoder.encode(url, "UTF-8");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return encodeString;
		
	}
	
}
