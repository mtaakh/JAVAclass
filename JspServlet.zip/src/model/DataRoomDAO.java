package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletContext;
import javax.sql.DataSource;

public class DataRoomDAO {
	
	//멤버변수
	private Connection conn;
	private ResultSet rs;
	private PreparedStatement psmt;
	
	//기본생성자 : 디비연결(커넥션풀 사용)
	public DataRoomDAO(){
		try{
			Context ctx = new InitialContext();
			DataSource source = (DataSource)ctx.lookup("java:comp/env/jdbc/myoracle");
			conn = source.getConnection();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	//자원반납
	public void close(){
		try{
			if(rs!=null) rs.close();
			if(psmt!=null) psmt.close();
			if(conn!=null) conn.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	//전체 레코드수 얻기
	public int getTotalRowCount(Map map){
		
		int  totalRecordCount = 0;
		try{
			/*
			테이블의 전체 레코드수를 세기 위해 그룹함수 count(*) 사용
			*/
			String sql = "select count(*) from dataroom ";
			
			//검색부분 쿼리 추가
			if(map.get("searchColumn")!=null && map.get("searchWord")!=null){
			sql += "where "+ map.get("searchColumn").toString() +" like '%"+ map.get("searchWord").toString() +"%'";
			}
			
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			rs.next();
			totalRecordCount = rs.getInt(1);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return totalRecordCount;
	}
	
	
	//리스트 출력을 위한 쿼리실행
	public List<DataRoomDTO> selectAll(Map map){
		
		List<DataRoomDTO> lists = new Vector<DataRoomDTO>();
		try{
			String sql = "select * from "
					+ " (select Tb.*, rownum R from "
					+ " ((select * from dataroom ";
	
				//검색부분 쿼리 추가
				if(map.get("searchColumn")!=null && map.get("searchWord")!=null){
				sql += "where "+ map.get("searchColumn").toString() +" like '%"+ map.get("searchWord").toString() +"%'";
				}
				
				sql+= " order by idx desc) Tb)) "
				+ " where R between ? and ?";
			psmt = conn.prepareStatement(sql);
			
			psmt.setInt(1, Integer.parseInt(map.get("start").toString()));
			psmt.setInt(2, Integer.parseInt(map.get("end").toString()));
			
			rs = psmt.executeQuery();
			
			while(rs.next()){
				DataRoomDTO dto = new DataRoomDTO();
				
				dto.setIdx(rs.getInt(1));
				dto.setName(rs.getString(2));
				dto.setTitle(rs.getString(3));
				dto.setContent(rs.getString(4));
				dto.setPostdate(rs.getDate(5));
				dto.setAttachedfile(rs.getString(6));
				dto.setDowncount(rs.getInt(7));
				
				lists.add(dto);
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return lists;
	}
	
	//입력 처리
	public int insert(DataRoomDTO dto){
		
		int affected = 0;
		try{
			String sql = "insert into dataroom (idx, name, pass, title, content, attachedfile, downcount) "
					+ "values (seq_dataroom.nextval, ?,?,?,?,?,0)";
			
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getName());
			psmt.setString(2, dto.getPass());
			psmt.setString(3, dto.getTitle());
			psmt.setString(4, dto.getContent());
			psmt.setString(5, dto.getAttachedfile());
			
			affected = psmt.executeUpdate();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return affected;
	}
	
	//상세보기 처리 - 레코드 하나 가져오기
	public DataRoomDTO selectOne(String idx){
		DataRoomDTO dto = null;
		
		try{
			String sql = "select * from dataroom where idx=?";
			
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, idx);
			rs = psmt.executeQuery();
			
			if(rs.next()){
				dto = new DataRoomDTO();
				
				dto.setIdx(rs.getInt(1));
				dto.setName(rs.getString(2));
				dto.setTitle(rs.getString(3));
				dto.setContent(rs.getString(4));
				dto.setPostdate(rs.getDate(5));
				dto.setAttachedfile(rs.getString(6));
				dto.setDowncount(rs.getInt(7));
				dto.setPass(rs.getString(8));
				
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return dto;
	}
	
	//패스워드 검증
	public boolean isCorrectPassword(String pass, String idx){
		boolean isCorr = true;
		
		try{
			String sql = "select count(*) from dataroom where "
					+ " pass=? and idx=?";
			
			psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, pass);
			psmt.setString(2, idx);
			rs = psmt.executeQuery();
			//select된 결과가 없을때
			rs.next();
			if(rs.getInt(1)==0)  isCorr = false;
			
		}
		catch(Exception e){
			isCorr = false;
			e.printStackTrace();
		}
		
		return isCorr;
	}
	
	//수정처리
	public int update(DataRoomDTO dto){
		
		int affected = 0;
		
		try{
			String sql = "update dataroom set "
					+ " name=?, title=?, pass=?, attachedfile=?, content=? "
					+ " where idx=?";
			psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, dto.getName());
			psmt.setString(2, dto.getTitle());
			psmt.setString(3, dto.getPass());
			psmt.setString(4, dto.getAttachedfile());
			psmt.setString(5, dto.getContent());
			psmt.setInt(6, dto.getIdx());
			
			affected = psmt.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return affected;
	}
	
	//삭제 처리
	public int delete(String idx){
		int affected = 0;
		
		try{
			String sql = "delete from dataroom where idx=?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, idx);
			affected = psmt.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return affected;
	}
	
	
	//다운로드 수 증가
	public void updateDownCount(String idx){
		try{
			String sql = "update dataroom set downcount = downcount+1 where idx=?";
			
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, idx);
			psmt.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	

}
