package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.sql.DataSource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletContext;

public class BbsDAO {
	private Connection conn;
	private ResultSet rs;
	private PreparedStatement psmt;
	
	//생성자 메소드 : DB연결
	public BbsDAO(ServletContext context)
	{
		/* 커넥션풀이 아니라 커넥션 객체를 직접 메모리에 생성하는 로직 */
		/*try{
			Class.forName(context.getInitParameter("JDBCDriver"));
			conn = DriverManager.getConnection(context.getInitParameter("ConnectionURL"), "java_user", "1234");
		}
		catch(Exception e){
			e.printStackTrace();
		}*/
		
		/* 커넥션 풀로 변경하기 : 톰캣이 만들어놓은 커넥션객체 가져다 쓰기 */
		try{
			Context ctx = new InitialContext();
			
			/*Context ctx = (Context)initctx.lookup("java:comp/env");
			DataSource source = (DataSource)ctx.lookup("jdbc/myoracle");
			위 두개 라인을 아래와 같이 합쳐서 사용해도 무방하다*/
			
			DataSource source = (DataSource)ctx.lookup("java:comp/env/jdbc/myoracle");
			conn = source.getConnection();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void close(){ // 자원반납
		try{
			if(rs!=null) rs.close();
			if(psmt!=null) psmt.close();
			if(conn!=null) conn.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	//회원여부 판단
	public boolean isMember(String id, String pass){
		try{
			String sql = "select count(*) from member where id=? and pass=?";
			psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, id);
			psmt.setString(2, pass);
			rs = psmt.executeQuery();
			rs.next();
			
			//조회된 회원이 없으면 false 반환
			if(rs.getInt(1)==0) return false;
		}
		catch(Exception e){ // 예외 발생시 무조건 false
			e.printStackTrace();
			return false;
		}
		//조회된 회원이 있으면 true 반환
		return true;
	}
	
	//게시판의 모든 레코드 출력
	public List<BbsDTO> selectAll(Map<String, Object> map){
		
		List<BbsDTO> bbs = new Vector<BbsDTO>();
		try{
			String sql = "select * from (" 
			+	"select Tb.* , rownum rNum "
			+	"from ( "
			+		"select B.*, M.name from bbs B join member M "
			+ 		"on B.id = M.id ";
			if(map.get("COLUMN")!=null){
					sql += "where "+ map.get("COLUMN") +" like '%"+ map.get("WORD") +"%'";
				}
				sql +=  "order by num desc "
			+	")  Tb "
			+") "
			+"where rNum between ? and ? ";
			System.out.println(sql);
			
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, Integer.parseInt(map.get("start").toString()));
			psmt.setInt(2, Integer.parseInt(map.get("end").toString()));
			
			rs = psmt.executeQuery(); //쿼리실행
			while(rs.next())
			{
				BbsDTO dto = new BbsDTO();
				
				dto.setNum(rs.getString(1)); // num
				dto.setTitle(rs.getString(2)); // title
				dto.setContent(rs.getString(3)); // content
				dto.setPostdate(rs.getDate(4)); // postdate
				dto.setId(rs.getString(5)); // id
				dto.setVisitcount(rs.getString(6)); // visitcount
				dto.setName(rs.getString(7)); // name
				
				bbs.add(dto);
			}
		
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return bbs;
	}
	
	//전체 레코드 수 얻기
	public int getTotalRecordCount(Map<String,Object> map){
		
		int totalRecord = 0;
		try{
			String sql = "select count(*) from bbs b join member m on m.id = b.id ";
			//검색어가 있을경우 검색조건을 쿼리에 추가
			if(map.get("WORD")!=null){
				sql += "where "+ map.get("COLUMN") +" like '%"+ map.get("WORD") +"%'";
			}
			
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			rs.next();
			totalRecord = rs.getInt(1);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return totalRecord;
	}
	
	//게시물 쓰기 - 글쓰기
	public int insert(BbsDTO dto){
		int affected = 0;
		try{
			String sql = "insert into bbs (num, id, title, content) values (seq_bbs_num.nextval, ?, ?, ?)";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getTitle());
			psmt.setString(3, dto.getContent());
			affected = psmt.executeUpdate();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return affected;
	}
	
	//게시물 읽기 - 글 상세보기
	public BbsDTO selectOne(String num){
		BbsDTO dto = null;
		try{
			String sql = "select b.*, username from bbs b join "
					+ " members m on m.userid = b.id where num=?";
				psmt = conn.prepareStatement(sql);
				psmt.setString(1, num);
				
				rs = psmt.executeQuery();
				
				if(rs.next()){
					dto = new BbsDTO();
					
					dto.setNum(rs.getString(1));
					dto.setTitle(rs.getString(2));
					dto.setContent(rs.getString(3));
					dto.setPostdate(rs.getDate(4));
					dto.setId(rs.getString(5));
					dto.setVisitcount(rs.getString(6));
					dto.setName(rs.getString(7));
				}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return dto;
		
	}
	
	//게시물 조회수 세기
	public void updateVisitCount(String num){
		try{
			String sql = "update bbs set visitcount=visitcount+1 "
					+ "where num=?";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, num);
			psmt.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	//게시물 수정 - 수정하기
	public int update(BbsDTO dto){
		int affected = 0;
	
		try{
			String sql = "update bbs set title=?, content=? "
					+ "where num=?";
			
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getTitle());
			psmt.setString(2, dto.getContent());
			psmt.setString(3, dto.getNum());
			
			affected = psmt.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return affected;
	}
	
	//게시물 삭제 - 삭제하기
	public int delete(String num){
		
		int affected = 0;
		
		try{
			String sql = "delete from bbs where num=?";

			psmt = conn.prepareStatement(sql);
			psmt.setString(1, num);
			affected = psmt.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return affected;
	}
	
}
