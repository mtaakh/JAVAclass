package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 * web.xml 에서 처리할때 매핑을 @Webservlet을 통해 처리할 수 있음
 * 서블릿을 작성할때 동시에 처리할수 있으므로 작성은  간단하지만 클래스가 많으면 유지보수가 힘듦 
*/
@WebServlet("/13Servlet/AnnoWebServlet.do")
public class AnnoWebServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException
	{
		//리퀘스트 영역에 데이터 저장
		req.setAttribute("message", "Annotation Servlet Success!");
		//서블릿 초기화 파라미터 읽기
		req.setAttribute("HELLO", this.getInitParameter("HELLO"));
		
		//포워드(잠시후)
		RequestDispatcher display = req.getRequestDispatcher("/13Servlet/HelloServlet.jsp");
		display.forward(req, resp);
		
		//서블릿 파일에서 즉시 출력하는 경우
		resp.setContentType("text/htnl; charset=utf-8;");
		PrintWriter pw = resp.getWriter();
		pw.println("<html>");
		pw.println("<head>");
		pw.println("<title>어노테이션을 이용한 매핑</title>");
		pw.println("</head>");
		pw.println("<body>");
		pw.println("<h2>어노테이션을 이용한 매핑 성공</h2>");
		pw.println("/body");
		pw.println("/html");
		
		

	}
	
}
