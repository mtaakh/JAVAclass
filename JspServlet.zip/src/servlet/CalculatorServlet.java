package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CalculatorServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException
	{
		//비즈니스로직
		int fnum = Integer.parseInt(req.getParameter("firstNum"));
		int snum = Integer.parseInt(req.getParameter("secondNum"));
		String operator = req.getParameter("operator");
		
		int retValue;
		switch(operator){
		case "+": 
			retValue = fnum + snum;
			break;
		case "-": 
			retValue = fnum - snum;
			break;
		case "*": 
			retValue = fnum * snum;
			break;
		case "/": 
			retValue = fnum / snum;
			break;
		default:
			retValue = 0;
		}
		
		req.setAttribute("calValue", "연산의 결과는 : "+retValue);
		req.getRequestDispatcher("/13Servlet/HelloServlet.jsp").forward(req, resp);
	}

}
