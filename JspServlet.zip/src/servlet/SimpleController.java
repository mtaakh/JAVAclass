package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
컨트롤러 서블릿이 전형적인 구현방식
*/
public class SimpleController extends HttpServlet {
	/*
		1단계 : HTTP 요청받음. Get이든 Post이든 proxessRrequest()메소드로 요청을 전달함
	*/
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
		throws ServletException, IOException
	{
		processRequest(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException
	{
		processRequest(req, resp);		
	}
	private void processRequest(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		//2단계 : 요청분석
		String type = req.getParameter("type");
		Object resultObj = null;
		//3단계 : 모델을 사용하여 요청한 기능을 수행한다(여기서는 모델이 없으므로 간단한 로직으로 처리함)
		if(type==null){
			resultObj = "파라미터가 없네용";
		}
		else if(type.equals("greeting")){
			resultObj = "Hi Hello 안녕";
		}
		else if(type.equals("date")){
			resultObj = new java.util.Date();
		}
		else{
			resultObj = "허어어어얼";
		}
		
		//4단계 : request영역이나 session영역에 처리결과를 저장
		req.setAttribute("result", resultObj);
		//5단계 :  RequestDispacther를 사용하여 알맞은 View로 포워딩하여 처리결과를 전달함
	 	RequestDispatcher rds = req.getRequestDispatcher("/13Servlet/SimpleView.jsp");
		rds.forward(req, resp);
		
	}
	
}
