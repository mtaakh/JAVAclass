package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.DataRoomDAO;
import model.DataRoomDTO;
import model.FileUtil;

public class DeleteCtrl extends HttpServlet {
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String idx = req.getParameter("idx");
		
		DataRoomDAO dao = new DataRoomDAO();
		
		//레코드 삭제 전 첨부파일을 삭제하기 위해 레코드 얻어오기
		DataRoomDTO dto = dao.selectOne(idx);
		
		int sucOrFail = dao.delete(idx);
		
		//레코드 삭제 성공시 업로드된 파일 삭제
		if(sucOrFail==1){
			String filename = dto.getAttachedfile();
			FileUtil.deleteFile(req, "/Upload", filename);
			
		}
		dao.close();
		
		//리퀘스트 영역에 데이터 저장
		req.setAttribute("WHATIS", "");
		req.setAttribute("SUC_FAIL", sucOrFail);
		
		req.getRequestDispatcher("/14DataRoom/Message.jsp").forward(req, resp);
		
	}
	
}
