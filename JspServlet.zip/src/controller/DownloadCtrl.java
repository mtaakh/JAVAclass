package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.DataRoomDAO;
import model.FileUtil;

public class DownloadCtrl extends HttpServlet {
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	//파라미터 받기
	String filename = req.getParameter("filename");
	String idx = req.getParameter("idx");
	
	FileUtil.download(req, resp, "/Upload", filename);
	
	//dataroom 테이블의 downcount +1 증가 로직
	DataRoomDAO dao = new DataRoomDAO();
	dao.updateDownCount(idx);
	dao.close();
		
		
	}
	
}
