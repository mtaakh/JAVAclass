package controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.DataRoomDAO;
import model.DataRoomDTO;
import model.PagingUtil;

public class ListCtrl extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException 
	{
		doGet(req,resp);
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		//비즈니스 로직
		/*
		1. 사용자 요청을 받음
		2. 요청 분석
		3. 모델에서 필요한 로직을 호출해서 결과값이 있으면 받음
		*/
		DataRoomDAO dao = new DataRoomDAO();
		Map parammap = new HashMap(); // 파라미터를 저장하기 위한 참조변수
		
		//페이징을 위한 로직
		String addQueryStr = "";
		String searchColumn = req.getParameter("searchColumn");
		String searchWord = req.getParameter("searchWord");
		
		if(searchColumn!=null && searchWord!=null){

			parammap.put("searchColumn", searchColumn);
			parammap.put("searchWord", searchWord);
			
			//페이징을 위한 파라미터 추가
			addQueryStr = "searchColumn="+searchColumn+"&searchWord="+searchWord+"&";
		}
		
		
		//전체 레코드 수를 카운트
		int totalRecordCount = dao.getTotalRowCount(parammap);
		
		/*
		서블릿 매핑 정보에 입력된 초기화변수를 가져옴
		PAGE_SIZE : 한페이지에 출력할 레코드 갯수
		BLOCK_PAGE : 하나의 페이지 블럭에 출력할 페이지 갯수
		*/
		int pageSize = Integer.parseInt(this.getInitParameter("PAGE_SIZE"));
		int blockPage = Integer.parseInt(this.getInitParameter("BLOCK_PAGE"));
		
		//전체 페이지 수
		int totalPage = (int)Math.ceil((double)totalRecordCount/pageSize);
		//현재 페이지를 파라미터로 받기
		int nowPage = req.getParameter("nowPage")==null ? 1 : Integer.parseInt(req.getParameter("nowPage"));
		
		//시작과 끝 rownum 구하기
		int start = (nowPage-1) * pageSize + 1;
		int end = nowPage * pageSize;
		
		//DAO로 넘길 파라미터 조립
		parammap.put("start", start);
		parammap.put("end", end);
		parammap.put("totalPage", totalPage);
		parammap.put("nowPage", nowPage);
		parammap.put("totalCount", totalRecordCount);
		parammap.put("pageSize", pageSize);
		
		//페이지 처리를 위한 문자열 생성
		String pagingImg = PagingUtil.pagingImg(totalRecordCount, pageSize, blockPage, nowPage, 
				req.getContextPath()+"/DataRoom/DataList?"+addQueryStr);
		
		//DAO 호출해서 레코드 가져오기
		List<DataRoomDTO> lists = dao.selectAll(parammap);
		
		//커넥션풀에 자원 반납
		dao.close();
		
		//반환되는 결과(View에 출력할 결과)를 리퀘스트영역에 저장
		req.setAttribute("lists", lists); // 결과 레코드셋
		req.setAttribute("pagingImg", pagingImg); // 페이지번호 출력 문자열
		req.setAttribute("map", parammap); // 파라미터
		
		
		//포워드
		RequestDispatcher dispatcher = req.getRequestDispatcher("/14DataRoom/DataList.jsp");
		dispatcher.forward(req, resp);
	}
	
}
