package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;

import model.DataRoomDAO;
import model.DataRoomDTO;

public class ViewCtrl extends HttpServlet {
	
	//doGet() 혹은 doPost()를 오버라이딩하지 않고 service() 메소드로 대체할 수 있음
	@Override
	public void service(ServletRequest req, ServletResponse resp) throws ServletException, IOException {
		
		//
		String idx = req.getParameter("idx");
		
		DataRoomDAO dao = new DataRoomDAO();
		DataRoomDTO dto = dao.selectOne(idx);
		
		//줄바꿈처리
		dto.setContent(dto.getContent().replaceAll("\r\n", "<br/>"));
		dao.close();
		
		//리퀘스트 영역에 값 저장
		req.setAttribute("dto", dto);
		
		//뷰 선택후 포워딩
		RequestDispatcher dis = req.getRequestDispatcher("/14DataRoom/DataView.jsp");
		dis.forward(req, resp);
		
	}
}
