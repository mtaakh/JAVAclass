package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;

import model.DataRoomDAO;
import model.DataRoomDTO;
import model.FileUtil;

public class WriteCtrl extends HttpServlet {
	
	//쓰기 입려폼으로 이동
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		// 포워드
		RequestDispatcher disp = req.getRequestDispatcher("/14DataRoom/DataWrite.jsp");
		disp.forward(req, resp);
	}
	
	//폼값을 받아서 쓰기를 처리하는 부분
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//한글처리 
		req.setCharacterEncoding("UTF-8");
		
		//파일 업로드를 위한 모델(비즈니스 로직) 호출
		MultipartRequest mr = FileUtil.upload(req, req.getServletContext().getRealPath("/Upload"));
		
		int sucOrFail; // DB입력 성공:1, 실패:0, 용량초과:-1 반환
		if(mr != null){//파일 업로드 성공시 데이터 입력처리
			//나머지 파라미터를 받아서 DB에 입력처리
			String name = mr.getParameter("name");
			String title = mr.getParameter("title");
			String pass = mr.getParameter("pass");
			String content = mr.getParameter("content");
			String attachedfile = mr.getFilesystemName("attachedfile");
			
			//데이터베이스 입력 위한 모델호출
			DataRoomDTO dto = new DataRoomDTO();
			dto.setAttachedfile(attachedfile);
			dto.setContent(content);
			dto.setName(name);
			dto.setPass(pass);
			dto.setTitle(title);
			
			DataRoomDAO dao = new DataRoomDAO();
			sucOrFail = dao.insert(dto); // 입력성공:1, 실패:0 반환
			dao.close();
			
		}
		else{ // 파일 업로드 실패시
			sucOrFail = -1;
		}
		
		/*if(sucOrFail==1){ // 성공일때
			req.getRequestDispatcher("/DataRoom/DataList").forward(req, resp);
			
		}
		else{ // 실패일때
			req.getRequestDispatcher("/14DataRoom/DataWrite.jsp").forward(req, resp);
		}*/
		
		//DB입력 성공여부 및 파일용량 초과 판단용 속성 저장
		req.setAttribute("SUC_FAIL", sucOrFail);
		//어느 컨트롤러에서 포워드 되었는지 판단
		req.setAttribute("WHEREIS", "INSERT");
		
		req.getRequestDispatcher("/14DataRoom/Message.jsp").forward(req, resp);
		
	}
	
}
