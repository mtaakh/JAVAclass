package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.DataRoomDAO;

public class PasswordCtrl extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//파라미터 받기
		String idx = req.getParameter("idx");
		String mode = req.getParameter("mode");
		
		//리퀘스트 영역에 파라미터 저장
		req.setAttribute("idx", idx);
		req.setAttribute("mode", mode);
		//뷰 선택후 포워딩
		RequestDispatcher dp = req.getRequestDispatcher("/14DataRoom/DataPassword.jsp");
		dp.forward(req, resp);
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//파라미터 받기
		String idx = req.getParameter("idx");
		String mode = req.getParameter("mode");
		String pass = req.getParameter("pass");
		
System.out.println("폼값: "+idx+", "+mode+", "+pass);
		//패스워드 검증을 위해 모델 호출
		DataRoomDAO dao = new DataRoomDAO();
		boolean isCorrect = dao.isCorrectPassword(pass,idx);
		dao.close();
		
		//결과값을 리퀘스트  영역에 저장
		req.setAttribute("PASS_CORRECT", isCorrect);
		req.getRequestDispatcher("/14DataRoom/PassMessage.jsp").forward(req, resp);
		
		
		
	}
	
}
