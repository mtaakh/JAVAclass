package controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;

import model.DataRoomDAO;
import model.DataRoomDTO;
import model.FileUtil;

public class EditCtrl extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//요청분석
		String idx = req.getParameter("idx");
		
		//모델호출
		DataRoomDAO dao = new DataRoomDAO();
		DataRoomDTO dto = dao.selectOne(idx);
		Map parammap = new HashMap(); // 파라미터를 저장하기 위한 참조변수
		dao.close();
		
		//현재 페이지를 파라미터로 받기
		int nowPage = req.getParameter("nowPage")==null ? 1 : Integer.parseInt(req.getParameter("nowPage"));

		parammap.put("nowPage", nowPage);
		
		//리퀘스트 영역에 저장
		req.setAttribute("dto", dto);
		req.setAttribute("map", parammap); // 파라미터
		
		//뷰 선택 후 포워드
		req.getRequestDispatcher("/14DataRoom/DataEdit.jsp").forward(req, resp);
		
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//한글처리
		req.setCharacterEncoding("UTF-8");
		
		MultipartRequest mr = FileUtil.upload(req, req.getServletContext().getRealPath("/Upload"));
		
		int sucOrFail;
		
		if(mr!=null){ // 파일업로드 성공
			//기타 파라미터는 MultipartRequest객체를 통해 받음
			int idx = Integer.parseInt(mr.getParameter("idx"));
			//수정 완료후 상세보기 화면으로 이동하기 위해 영역에 저장
			req.setAttribute("idx", idx);
			
			String name = mr.getParameter("name");
			String title = mr.getParameter("title");
			String content = mr.getParameter("content");
			String pass = mr.getParameter("pass");
			String attachedfile = mr.getFilesystemName("attachedfile");
			
			if(attachedfile==null){
				attachedfile = mr.getParameter("originalfile");
			}
			
			DataRoomDTO dto = new DataRoomDTO();
			dto.setIdx(idx);
			dto.setName(name);
			dto.setTitle(title);
			dto.setContent(content);
			dto.setPass(pass);
			dto.setAttachedfile(attachedfile);
			
			//업데이트 - 
			DataRoomDAO dao = new DataRoomDAO();
			sucOrFail = dao.update(dto);
			
			//업데이트 성공 & 새로운 파일 업로드 완료
			if(sucOrFail==1 && mr.getFilesystemName("attachedfile")!=null){
				FileUtil.deleteFile(req, "/Upload", mr.getParameter("originalfile"));
			}
			dao.close();
			
		}
		else{//파일업로드 실패
			sucOrFail = -1;
		}
		
		//리퀘스트 영역 저장
		req.setAttribute("SUC_FAIL", sucOrFail);
		req.setAttribute("WHEREIS", "UPDATE");
		
		
		req.getRequestDispatcher("/14DataRoom/Message.jsp").forward(req, resp);
		
		
	}
	
}
